# A Lean 4 Toolbox for First-Order Term Rewriting: Critical Pairs, Newman Confluence, and Completion Orderings

**Artifact for ITP 2026 Short Paper**

This artifact accompanies the paper *"A Lean 4 Toolbox for First-Order Term Rewriting: Critical Pairs, Newman Confluence, and Completion Orderings"*.

## Building

**Requirements:** Lean 4 (via [elan](https://github.com/leanprover/elan))

```bash
lake build
```

The build should complete with **no errors and no warnings**. No axioms or `sorry` placeholders are used.

---

## Paper-to-Code Mapping

### Section 1: Overview and Contributions

| Paper Reference | File | Key Definitions/Theorems |
|-----------------|------|--------------------------|
| Namespace `Metatheory.TRS.FirstOrder` | `Metatheory/TRS/FirstOrder/` | All first-order TRS modules |
| Generic rewriting layer | `Metatheory/Rewriting/Basic.lean` | Reflexive-transitive closure, joinability |
| Newman's Lemma | `Metatheory/Rewriting/Newman.lean` | `newman` |

### Section 2: Critical Pair Computation (Soundness and Completeness)

| Paper Reference | File | Key Definitions/Theorems |
|-----------------|------|--------------------------|
| `overlapsOfRules` | `Metatheory/TRS/FirstOrder/CriticalPairs.lean` | `overlapsOfRules` |
| `criticalPairsOfRules` | `Metatheory/TRS/FirstOrder/CriticalPairs.lean` | `criticalPairsOfRules` |
| Soundness theorem | `Metatheory/TRS/FirstOrder/CriticalPairs.lean` | `criticalPairsOfRules_sound` |
| Completeness theorem | `Metatheory/TRS/FirstOrder/CriticalPairs.lean` | `criticalPairsOfRules_complete` |
| Robinson unification | `Metatheory/TRS/FirstOrder/Unification.lean` | Unification algorithm |
| Unification completeness | `Metatheory/TRS/FirstOrder/UnificationComplete.lean` | Completeness proof |

### Section 3: Termination (Stable Orderings and Dependency Pairs)

| Paper Reference | File | Key Definitions/Theorems |
|-----------------|------|--------------------------|
| KBO-style stable weight ordering | `Metatheory/TRS/FirstOrder/Ordering.lean` | `stableWeightLt` |
| Well-foundedness of weight ordering | `Metatheory/TRS/FirstOrder/Ordering.lean` | `stableWeightLt_wf` |
| Lexicographic path ordering (LPO) | `Metatheory/TRS/FirstOrder/LPO.lean` | `LPO` |
| LPO well-foundedness | `Metatheory/TRS/FirstOrder/LPO.lean` | `lpo_wf` |
| Substitution-stable LPO | `Metatheory/TRS/FirstOrder/LPO.lean` | `StableLPO` |
| Dependency pairs | `Metatheory/TRS/FirstOrder/DependencyPairs.lean` | `dependencyPairs` |
| Termination criterion | `Metatheory/TRS/FirstOrder/DependencyPairs.lean` | `terminating_of_rules_and_dependencyPairs_ordering` |

### Section 4: Completion and Fixpoint-Based Certificates

| Paper Reference | File | Key Definitions/Theorems |
|-----------------|------|--------------------------|
| Completion step relation | `Metatheory/TRS/FirstOrder/Completion.lean` | `CompletionStep` |
| Reflexive-transitive closure | `Metatheory/TRS/FirstOrder/Completion.lean` | `Completion` |
| Fuel-bounded completion | `Metatheory/TRS/FirstOrder/Completion.lean` | `completionWithFuel` |
| Completion result type | `Metatheory/TRS/FirstOrder/Completion.lean` | `CompletionResult` |
| Universe bounds | `Metatheory/TRS/FirstOrder/Completion.lean` | `RuleUniverse` |
| Fixpoint theorem | `Metatheory/TRS/FirstOrder/Completion.lean` | `completionIter_fixpoint_of_universe` |
| Knuth-Bendix certificate | `Metatheory/TRS/FirstOrder/Completion.lean` | `KnuthBendixComplete` |
| Unique normal forms | `Metatheory/TRS/FirstOrder/Completion.lean` | `completion_existsUnique_normalForm` |
| Confluence (KB criterion) | `Metatheory/TRS/FirstOrder/Confluence.lean` | Confluence via critical pairs |

### Section 5: Case Studies

| Paper Reference | File | Key Definitions/Theorems |
|-----------------|------|--------------------------|
| Boolean TRS | `Metatheory/TRS/FirstOrder/BooleanCaseStudy.lean` | Boolean operations TRS |
| Boolean KB certificate | `Metatheory/TRS/FirstOrder/BooleanCaseStudy.lean` | `boolean_knuthBendixComplete` |
| Boolean confluence | `Metatheory/TRS/FirstOrder/BooleanCaseStudy.lean` | `boolean_confluent` |
| Boolean termination | `Metatheory/TRS/FirstOrder/BooleanCaseStudy.lean` | `boolean_terminating` |
| Group-theoretic TRS | `Metatheory/TRS/FirstOrder/GroupTheory.lean` | Group identities TRS |
| Tutorial example | `Metatheory/TRS/FirstOrder/Examples.lean` | Ground TRS example |

---

## Module Overview

### Core TRS Infrastructure (`Metatheory/TRS/FirstOrder/`)

| Module | Description | LOC |
|--------|-------------|-----|
| `Syntax.lean` | Terms, substitutions, positions | ~400 |
| `Rules.lean` | Rewrite rules, rewriting relation | ~300 |
| `Positions.lean` | Position-based term operations | ~350 |
| `Unification.lean` | Robinson unification algorithm | ~400 |
| `UnificationComplete.lean` | Completeness of unification | ~250 |
| `CriticalPairs.lean` | Overlap/critical pair enumeration | ~500 |
| `Ordering.lean` | KBO-style stable weight ordering | ~350 |
| `LPO.lean` | Lexicographic path ordering | ~450 |
| `DependencyPairs.lean` | Dependency pairs termination | ~300 |
| `Confluence.lean` | Critical pair confluence criterion | ~400 |
| `Completion.lean` | Knuth-Bendix completion | ~600 |

### Case Studies (`Metatheory/TRS/FirstOrder/`)

| Module | Description |
|--------|-------------|
| `BooleanCaseStudy.lean` | Boolean operations with full certificates |
| `GroupTheory.lean` | Group-theoretic identities with certificates |
| `Examples.lean` | Tutorial/regression test examples |

### Generic Rewriting Layer (`Metatheory/Rewriting/`)

| Module | Description |
|--------|-------------|
| `Basic.lean` | Abstract rewriting, closures, joinability |
| `Newman.lean` | Newman's Lemma |
| `Diamond.lean` | Diamond property |
| `HindleyRosen.lean` | Hindley-Rosen theorem |
| `DecreasingDiagrams.lean` | Decreasing diagrams framework |

---

## Key Theorems

### Critical Pairs
```lean
theorem criticalPairsOfRules_sound : ...
theorem criticalPairsOfRules_complete : ...
```

### Termination
```lean
theorem stableWeightLt_wf : WellFounded stableWeightLt
theorem lpo_wf : WellFounded (LPO prec)
theorem terminating_of_rules_and_dependencyPairs_ordering : ...
```

### Completion
```lean
theorem completionIter_fixpoint_of_universe : ...
theorem completion_existsUnique_normalForm : ...
```

### Case Studies
```lean
theorem boolean_knuthBendixComplete : KnuthBendixComplete booleanRules ...
theorem boolean_confluent : Confluent (rewriteRelation booleanRules)
theorem boolean_terminating : Terminating (rewriteRelation booleanRules)
```

---

## Statistics

- **Total lines:** ~9,000 (TRS + Rewriting modules)
- **Axioms:** None
- **Sorry:** None
- **Warnings:** None

---

## License

See LICENSE file (if included) or contact authors.
